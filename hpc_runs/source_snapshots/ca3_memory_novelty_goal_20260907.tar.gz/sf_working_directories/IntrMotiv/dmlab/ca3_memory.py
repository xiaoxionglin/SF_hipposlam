"""Finite CA3 novelty, re-entry inhibition, and graph-free intrinsic goals."""
import torch
from torch.nn import functional as F

# Episode-local target, elapsed decisions, arrival reward, ambiguous arrival;
# final replay-only target descriptor survives environment reset.
GOAL_STATE_SIZE = 5


def inhibit_reentry(activity, previous_ca3, mode):
    memory = previous_ca3.detach().amax(dim=-1)
    continuing = previous_ca3[..., 0].gt(0)
    if mode == "none":
        return activity
    if mode == "hard":
        return activity * (continuing | memory.eq(0))
    if mode == "trace_subtractive":
        return torch.where(continuing, activity, (activity - memory).clamp_min(0))
    raise ValueError(f"Unknown re-entry inhibition: {mode}")


def absent_event_gate(progression, dominant, empty_distance):
    previous = progression.roll(1, dims=1)
    gate = (dominant & previous.eq(empty_distance)).any(dim=-1)
    gate[:, 0] = False
    return gate


def advance_goal(state, previous_ca3, updated_ca3, horizon, scale, refractory):
    """Resolve the previous command before sampling the next absent identity."""
    result = torch.zeros_like(state)
    target = state[:, 0].long()
    elapsed = state[:, 1] + 1
    active = target.gt(0)
    n = updated_ca3.size(-2)
    safe = (target - 1).clamp(0, n - 1)
    current = updated_ca3[..., 0]
    # Match the established dominant-onset refractory event definition.
    candidates = current.gt(0) & ~previous_ca3[..., :refractory].gt(0).any(-1)
    dominant = current.masked_fill(~candidates, -torch.inf).argmax(-1)
    hit = active & candidates.any(-1) & dominant.eq(safe)
    entered = active & current.gather(1, safe[:, None]).squeeze(1).gt(0)
    ambiguous = entered & ~hit
    hit &= elapsed.le(horizon)
    result[:, 2] = hit * (horizon + 1 - elapsed).clamp_min(0) * scale
    result[:, 3] = ambiguous
    ended = ~active | entered | elapsed.ge(horizon)
    result[:, 0] = torch.where(ended, 0, target)
    result[:, 1] = torch.where(ended, 0, elapsed)
    absent = updated_ca3.amax(-1).eq(0)
    choose = ended & absent.any(-1)
    if choose.any():
        # Uniform categorical sampling; never use a historical cumulative graph.
        sampled = torch.multinomial(absent[choose].float(), 1).squeeze(1)
        result[choose, 0] = (sampled + 1).to(result.dtype)
    result[:, -1] = result[:, 0]
    goal = F.one_hot((result[:, 0].long() - 1).clamp_min(0), n)
    goal = goal.to(current.dtype) * result[:, 0:1].gt(0)
    return result, goal
